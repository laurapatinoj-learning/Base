/* Dirección del servidor del juego (Render). Vacío = mismo origen. */
window.KMS_CONFIG = { api: "" };
